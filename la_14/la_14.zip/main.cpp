#include <iostream>
#include "Menu.h"
using namespace std;


int main(){
    Menu menu;
    while(true){
        menu.menu();
        system("pause");
        system("cls");
    }
    return 0;
}
