#include "Customer.h"


Customer::Customer()
{
    //ctor
}


Customer::~Customer()
{
    //dtor
}
